"""
V2 API Module
"""

from .health import health_bp

__all__ = ['health_bp']
