"""
Customer Profile - Model Module
"""

from .customer import Customer

__all__ = ['Customer']
