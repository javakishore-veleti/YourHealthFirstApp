"""
Customer Profile - DAO Implementation Module
"""

from .customer_dao_impl import CustomerDAOImpl

__all__ = ['CustomerDAOImpl']
