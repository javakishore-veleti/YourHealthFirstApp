"""
Customer Profile - Service Implementation Module
"""

from .customer_service_impl import CustomerServiceImpl

__all__ = ['CustomerServiceImpl']
